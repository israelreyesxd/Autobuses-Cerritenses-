# Autobuses Cerritenses

Sitio web estático optimizado para Vercel o cualquier hosting compartido.

## Estructura

- `index.html`: Página principal.
- `vercel.json`: Configuración para despliegue automático en Vercel.

## Despliegue en Vercel

1. Ve a https://vercel.com/import
2. Sube esta carpeta como nuevo proyecto.
3. ¡Listo!

## Despliegue manual

1. Sube el archivo `index.html` a tu servidor o hosting.
2. Asegúrate de que la ruta raíz esté configurada correctamente.

